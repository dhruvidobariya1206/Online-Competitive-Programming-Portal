<?php
    session_start();  
    include("./connection2.php");    
      
    $email = $_POST['email'];  
    
    $sql = "SELECT * FROM users WHERE email = '".$email."'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) 
    {
        $row = $result->fetch_assoc();
        //echo $row['email_id'];
        $_SESSION["email"] =  $row['email'];  
        header("Location: ./mailverification.php");
    } 
    else 
    {
        echo "Email Id and Password are NOT correct";
    }
    $conn->close();
?>