<?php
    session_start();
    include("./connection2.php");
    $random_variable = rand(10000000,99999999);

    $sql = "UPDATE users SET passward=$random_variable WHERE email = '".$_SESSION["email"]."'";
    //AND password= '".$password."'
    $result = $conn->query($sql);
    
    $conn->close();

    require_once("./include/PHPMailer.php");
    require_once("./include/SMTP.php");

    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->SMTPDebug = 3;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "tls";
        $mail->Port = 587;

        $mail->Username = 'dkana1206@gmail.com';
        $mail->Password = 'dkd120602';

        // Sender and recipient settings
        //$email_id = $_POST['email'];
        $mail->setFrom('ddobariya5262@gmail.com', 'Online Competitive Programming Portal');
        $mail->addAddress($_SESSION["email"]);
    
        // Setting the email content
        $mail->IsHTML(true);
        $mail->Subject = "Reset Password";
        $mail->Body = $random_variable;
        $mail->AltBody = $random_variable;

        $mail->send();
        // echo "Email message sent.";
    } 
    catch (Exception $e) 
    {
         echo "Error in sending email. Mailer Error: {$mail->ErrorInfo}";
    }
?>
