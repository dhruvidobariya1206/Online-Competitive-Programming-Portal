<?php    
    include("./connection2.php");

    $email = $_POST['email'];
    $password = $_POST['password'];  

    //$sql = "INSERT INTO users (`email`, `password`) VALUES ('$email', '$password')";

    // if ($conn->query($sql) === TRUE) 
    // {
    //     echo "New record created successfully";
    // } 
    // else 
    // {
    //     echo "Error: " . $sql . "<br>" . $conn->error;
    // } 
    // $sql = "SELECT * FROM users WHERE email = '".$email."'";
    // $result = $conn->query($sql);
    $sql = "select * from users where email= '".$email."' ";
    //echo $sql;        
    $result = $conn->query($sql);
    // $get_user=mysqli_num_rows($result);
    // echo $get_user;
    //echo $result->num_rows;
    if($result->num_rows > 0){
        echo 'User already exists';
    }
    else {
        $sql = "INSERT INTO users(`email`, `passward`) VALUES ('$email', '$password')";
        if ($conn->query($sql) === TRUE) 
        {
            echo "New record created successfully";
        } 
        else 
        {
            echo "Error: " . $sql . "<br>" . $conn->error;
        } 
    }
    $conn->close();
?>