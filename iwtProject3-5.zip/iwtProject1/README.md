# Online-Compiler-Windows-Server
This is an Online Compiler For Windows Server 

# SET UP

```
Install CodeBlocks IDE
```

```
Go To  Codeblocks Installed Folder bin Location And Copy The Path. Mine Is

C:\Program Files (x86)\CodeBlocks\MinGW\bin

```

```
Then Set Your Compiler Path On Environment Variable From Windows System Property Otherwise It will not work 

```

```
At Last Replace Path in putenv() function by your path

```

For Java Install Java
```
Go To Java Installed Folder bin Location And Copy The Path. Mine Is

C:\Program Files (x86)\Java\jdk1.8.0_112\bin

```


```
At Last Replace Path in putenv() function by your path
```

