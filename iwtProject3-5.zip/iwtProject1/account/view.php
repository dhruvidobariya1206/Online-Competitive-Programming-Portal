<?php 

    require_once("connection2.php");
    $query = " select * from users ";
    $result = mysqli_query($con,$query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Records</title>
    <link rel="icon" type="image/x-icon" href="../img/ruet.png">
</head>
<body class="bg-dark">

        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card mt-5">
                        <table class="table table-bordered" border ="1" align = "center">
                            <tr>
                                <td> ID </td>
                                <br>
                                <td> Topic </td>
                                
                                
                            </tr>

                            <?php 
                                    
                                    while($row=mysqli_fetch_assoc($result))
                                    {
                                        $ID = $row['id'];
                                        $TopicName = $row['Topic'];
                                        
                            ?>
                                    <tr>
                                        <td><?php echo $ID ?></td>
                                        <td><?php echo $TopicName ?></td>
                                       
                                        <td><a href="edit.php?ID=<?php echo $ID ?>">Edit</a></td>
                                        <td><a href="update.php?Del=<?php echo $ID ?>">Delete</a></td>
                                    </tr>        
                            <?php 
                                    }  
                            ?>                                                                    
                                   

                        </table>
                    </div>
                </div>
            </div>
        </div>
    
</body>
</html>