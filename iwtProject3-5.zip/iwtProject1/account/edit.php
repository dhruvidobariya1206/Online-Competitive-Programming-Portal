<?php 
    require_once("../passward/connection2.php");
    session_start();
    $ID = $_SESSION['user_id'];
    // echo "ID : ". $ID;
    // echo exit(0);
    $query = "SELECT * FROM users where id='".$ID."'";
    $result = mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="icon" type="image/x-icon" href="../img/ruet.png">
    <style>
        .tr1{
            height: 240px;
        }
        td {
            width: 35%;
        }
        form {
            height: 150px;
            width: 300px;
        }
        input {
            height: 25px;
            width: 500px;
        }
    </style>
</head>
<body class="bg-dark" style="background-color: lightgrey; padding-top: 20px; text-align: center;">

        <div class="container">
            <table style="width:100%; text-align: center;">
                <tr class="tr1">
                    <td></td><td></td><td></td>
                </tr>
                <tr class="tr1">
                    <td></td>
                    <td style="text-align: center;">
                        <form action="update.php?ID=<?php echo $ID ?>" method="post">
                            <?php
                                if($result -> num_rows > 0)
                                {
                                    while($row = $result -> fetch_assoc())
                                {
                            ?>            
                            <input type="text" class="form-control mb-2" placeholder="username" name="username" value="<?php echo $row['username']?>"><br><br>
                            <input type="text" class="form-control mb-2" placeholder="email" name="email" value="<?php echo $row['email']?>"><br><br>
                            <input type="text" class="form-control mb-2" placeholder="password" name="password" value="<?php echo $row['passward']?>"><br><br>
                                
                            <button class="btn btn-primary" name="update">Update</button>
        
                            <?php
                                }
                                }
                            ?>
                        </form>

                    </td>
                    <td></td>
                </tr>
                <tr class="tr1">
                    <td></td><td></td><td></td>
                </tr>
            </table>
        </div>
    </body>
</html>