<?php
    require_once("../passward/connection2.php");
    $ID = $_GET['ID'];
    // echo "ID: ", $ID;
    // echo exit(0);

    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    // echo "email: ". $email;
    // echo exit(0);

    $update = "UPDATE `users` set username = '$username' , email = '$email' , passward = '$password' WHERE id = $ID";
    $result = mysqli_query($conn,$update);

    if($result)
    {
        header("location: ../dash/dashboard.php");
    }
    else
    {
        echo ' Please Check Your Query ';
    }
?>