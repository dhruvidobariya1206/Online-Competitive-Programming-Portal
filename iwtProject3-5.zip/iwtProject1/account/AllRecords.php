<?php 
    include('../passward/connection2.php');
    $count1 = mysqli_query($conn,"SELECT COUNT(*) as id FROM `users` WHERE `status`=1");
    $row_count = $count1->fetch_assoc();
    session_start();
    $name = $_SESSION['username'];
    $size=3;
    $start=0;
    $totalpage = ceil($row_count['id']/$size);
    if(isset($_POST['paging'])){
        $start = ceil((($_POST['paging'])-1)*$size);
    }
    $SELECT = "SELECT * FROM users WHERE status='1' LIMIT $start,$size";
    // $SELECT = "SELECT * FROM users WHERE `status`='1' AND `username`='".$name."'";
    $result = mysqli_query($conn, $SELECT);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>All Records</title>
    <link rel="icon" type="image/x-icon" href="../img/ruet.png">  
</head>
<body class="bg-dark" style="background-color: lightgrey; text-align: center">
   
        <div class="container" style="text-align: center">
        <center>
                        <table class="table table-bordered" border=1 style="background-color: darkgrey; border-radius: 10px; text-align: center">
                            <tr>
                                <td> ID </td><br>
                                <td> username </td>
                                <td> email </td>
                                <td> password </td>
                                <td> update </td>
                                <td> delete</td>   
                            </tr>

                            <?php 
                                if($result->num_rows > 0)  
                                {
                                    while($row = $result->fetch_assoc())
                                    {
                                        // for()
                                        $ID = $row['id'];
                                        $username = $row['username'];
                                        $email = $row['email'];        
                                        $password = $row['passward'];        
                            ?>
                                    <tr>
                                        <td><?php echo $ID ?></td>
                                        <td><?php echo $username ?></td>
                                        <td><?php echo $email ?></td>
                                        <td><?php echo $password ?></td>
                                        <td><a href="edit.php?ID=<?php echo $ID ?>">Update</a></td>
                                        <td><a href="delete.php?ID=<?php echo $ID ?>">Delete</a></td>
                                    </tr>  
                            <?php 
                                    }  
                                }
                                    echo "<table><tr>";
                                    for ($i=1; $i <= $totalpage ; $i=$i+1) { 
                                        echo "<td>
                                        <form method='post' action='./AllRecords.php'>
                                        <input type='hidden' name='paging' value='$i'></input>
                                        <button type='submit' value='$i'>$i</button>
                                        </form></td>";
                                    }
                                    echo "</tr></table>";
                            ?>          
                        </table>
                        <center>
                    </div>
    
</body>
</html>