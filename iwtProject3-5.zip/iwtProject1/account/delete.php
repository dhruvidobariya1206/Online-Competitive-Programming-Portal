<?php
    require_once("../passward/connection2.php");

    $ID = $_GET['ID'];
    $query = "UPDATE users set status = 0 where id = '".$ID."'";
    $result = mysqli_query($conn,$query);
    if($result)
    {
        header("location:AllRecords.php");
    } 
    else
    {
        echo ' Please Check Your Query ';
    }
?>