<?php
    // error_reporting(0);
    session_start();
    include('./passward/connection2.php');
    $username = $_POST['user'];
    $email = $_POST['email'];
    $password = $_POST['pass'];
    
    $SELECT = "SELECT * FROM users where `username` = '$username' AND `email` = '$email' AND `passward` = '$password' AND `status`='1'";  
    $result = $conn->query($SELECT);

    if($result->num_rows > 0)
    {
        while($row = $result->fetch_assoc())
        {
            if($row['category'] == 'admin')
            {
                header('Location: ./dash/dashboard.php');
            }

            if($row['category'] == 'user')
            {
                $_SESSION['username'] = $_POST['user'];
                $_SESSION['user_id'] = $row['id'];
                header('Location: ./dash/dashboard.php');
            }

            else
            {
                // echo "Error : " . $row;
                ?>
                <script >
                        alert("Enter valid details");
                </script>
                <?php
            }
        }
    }
?>