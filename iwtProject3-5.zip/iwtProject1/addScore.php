<?php
    session_start();
    include("./passward/connection2.php");
    // $username = $_SESSION['username'];
    $TaskID = $_GET['ID'];
    echo "Task id".$TaskID;
    // echo "username".$username;
    $output = $_GET['output'];
    echo $output;
    exit(0);

    $score = "SELECT * from `problems` where `id` = $TaskID";
    $result = $conn->query($score);
    $row = $result->fetch_assoc();
    $points = $row['Points'];
    $out = $row['output'];
    // echo "points".$points;

    if($output=$out)
    {

    }
    else
     {

    }

    $userScore = "SELECT * from `users` where `id` = '".$_SESSION['user_id']."' ";
    $result1 = $conn->query($userScore);
    $row1 = $result1->fetch_assoc();
    $rank = $row1['Score'];
    // echo "Score".$rank . "<br>";

    $addition_score =  $points + $rank; 

    $SELECT = "UPDATE `users` SET `Score` = $addition_score where `id` = '".$_SESSION['user_id']."' ";
    if($result = $conn->query($SELECT))
    {
        // header('Location: ./dash/dashboard.php');
    }
    // $insrt = "INSERT INTO completed (userid,taskid) VALUES (".$_SESSION['user_id'].",".$TaskID.")";
    //           $result1 = $conn->query($insrt);
?>