<?php
    // include('../passward/connection2.php');

    // $level = $_POST['level'];
    // // echo $level;

    // $count1 = mysqli_query($conn,"SELECT COUNT(*) as id FROM `problems` WHERE `difficulty` = '$level'");
    // $row_count = $count1->fetch_assoc();

    // $SELECT = "SELECT * FROM `problems` where `difficulty` = '$level';";  
    // $result = $conn->query($SELECT);

    // if($result->num_rows > 0)  
    // {
    //     while($row = $result->fetch_assoc())
    //     {
    //         $ID = $row['id'];
    //         $statement = $row['statement'];
    //         $difficulty = $row['difficulty'];        
    //         // $password = $row['passward'];        
            
    //                                     <tr>
    //                                     <td><?php echo $ID </td>
    //                                     <td><?php echo $username </td>
    //                                     <td><?php echo $email </td>
    //                                     <td><?php echo $password </td>
    //                                     <td><a href="edit.php?ID=<?php echo $ID ">Update</a></td>
    //                                     <td><a href="delete.php?ID=<?php echo $ID ">Delete</a></td>
    //                                 </tr>  
    //     }
    // }

?>