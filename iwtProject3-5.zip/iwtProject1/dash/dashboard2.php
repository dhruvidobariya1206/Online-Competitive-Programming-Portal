<?php
    error_reporting(0);
    session_start();  
    include("../passward/connection2.php"); 
    // $level="";

    // function allTasks() {
        // echo "Hello world!";
        // $sql = "SELECT Count(*) FROM problems";
        // $result = $conn->query($sql);

    // }
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.4/css/bulma.min.css'>
  <link rel="stylesheet" href="./dashbrd2.css">
  <link rel="icon" type="image/x-icon" href="../img/ruet.png">
</head>
<body>
<!-- partial:index.partial.html -->
<div class="page">

  <nav class="menu">

    <div class="name">
     
      <!-- <div class="cross">
         <img src="../img/cross.png" alt="cross">
      </div> -->
      <div>Menu</div>
    </div>

    <ul style="list-style-type:none;">
      <li></li>
      <li class="active" style="padding-left: 30px; font-size: x-large; font-weight: bold;">
          <!-- <div class="image"><img src="../img/ict.png" alt="image"></div> -->
        <?php 
            $name = "SELECT * from `users` where `id` = '".$_SESSION['user_id']."' ";
            $result1 = $conn->query($name);
            $row1 = $result1->fetch_assoc();
            $username = $row1['username'];
            // echo $_SESSION['username'];
            echo $username;
        ?>
      </a></li><br>
      <li class="active" style="padding-left: 15px; font-size: x-large;"><i>Score : </i>
        <?php
          $userScore = "SELECT * from `users` where `id` = '".$_SESSION['user_id']."' ";
          $result1 = $conn->query($userScore);
          $row1 = $result1->fetch_assoc();
          echo $row1['Score'];
        ?>
      </li><br>
      <li class="active"><a href="../account/edit.php"><i>Update Profile</i></a></li><br>
      <li class="active"><a href="#"><i>Discussions</i></a></li><br>
      <li class="active"><a href='<?php 

                              ?>'><i>Tasks</i></a></li><br>
      <!-- <li class="active"><a href="#"><i>Score</i></a></li><br> -->
      <li class="active"><a href="../home.php"><i>Practice Coding</i></a></li><br>
      <li class="active"><a href="../logout.php"><i>Logout</i></a></li><br>
  </ul>

    <div class="note">
      <h3>Created by Dhruvi Dobariya</h3>
      <p>ICT Department, Marwadi University</p>
    </div>

  </nav>

  <main>
    <header>
        <div clas="Tasks" style="display: flex;">
            <div>Pending</div>
            <div>Done</div>
        </div>
        
    </header>
      
    </div>

  </main>

</div>
<!-- partial -->
  <!-- <script  src="./script.js"></script> -->

</body>
</html>
