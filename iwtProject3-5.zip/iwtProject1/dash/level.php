<?php
            $level = $_POST['level'];
            echo $level;
            // exit(0);
            // $count1 = mysqli_query($conn,"SELECT * FROM `problems` WHERE `difficulty` = '$level'");
            // $count1 = mysqli_query($conn,"SELECT COUNT(*) as id FROM `problems` WHERE `difficulty` = '$level'");
            // $row_count = $count1->fetch_assoc();
  
            // $SELECT = "SELECT * FROM(
            //                           SELECT `id` FROM problems WHERE `difficulty` = '$level'
            //                           -
            //                           SELECT taskid FROM completed where userid='".$_SESSION['user_id']."');";  
            // $result = $conn->query($count1);
  
            // if($result->num_rows > 0)  
            // {
            //   while($row = $result->fetch_assoc())
            //   {
            //     $ID = $row['id'];
            //     // echo $ID;
            //     // exit(0);
            //     $statement = $row['statement'];
            //     $difficulty = $row['difficulty'];
            //     $points = $row['Points'];
            //     // $password = $row['passward'];        
            //     // echo "<div class="item">".$ID.")".$statement.""."</div>";
            //     echo " <div class='content-columns'><div class='col'><table class='tasks'><tr><td>".$ID."</td><td>".$statement."</td><td>".$difficulty."</td><td>".$points."</td>";
            //     echo "<td><a href='../home.php?ID=$ID'><input type='submit' value='Select'></a></td></tr></table></div></div>";
            //     // $_SESSION['task'] = $ID;
            //   }
            // }
?>