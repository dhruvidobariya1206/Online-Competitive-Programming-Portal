<?php
    error_reporting(0);
    session_start();  
    include("../passward/connection2.php"); 
    // $level="";

    // function allTasks() {
        // echo "Hello world!";
        // $sql = "SELECT Count(*) FROM problems";
        // $result = $conn->query($sql);

    // }
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.4/css/bulma.min.css'>
  <link rel="stylesheet" href="./dashbrd.css">
  <link rel="icon" type="image/x-icon" href="../img/ruet.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
<!-- partial:index.partial.html -->
<div class="page">

<nav class="menu">

<div class="name">
 
  <!-- <div class="cross">
     <img src="../img/cross.png" alt="cross">
  </div> -->
  <div>Menu</div>
</div>

<ul style="list-style-type:none;">
  <li></li>
  <li class="active" style="padding-left: 30px; font-size: x-large; font-weight: bold;">
      <!-- <div class="image"><img src="../img/ict.png" alt="image"></div> -->
    <?php 
        $name = "SELECT * from `users` where `id` = '".$_SESSION['user_id']."' ";
        $result1 = $conn->query($name);
        $row1 = $result1->fetch_assoc();
        $username = $row1['username'];
        // echo $_SESSION['username'];
        echo $username;
    ?>
  </a></li><br>
  <li class="active" style="padding-left: 15px; font-size: x-large;"><i>Score : </i>
    <?php
      $userScore = "SELECT * from `users` where `id` = '".$_SESSION['user_id']."' ";
      $result1 = $conn->query($userScore);
      $row1 = $result1->fetch_assoc();
      echo $row1['Score'];
    ?>
  </li><br>
  <li class="active"><a href="../account/edit.php"><i>Update Profile</i></a></li><br>
  <li class="active"><a href="#"><i>Discussions</i></a></li><br>
  <li class="active"><a href='<?php ?>'><i>Tasks</i></a></li><br>
  <!-- <li class="active"><a href="#"><i>Score</i></a></li><br> -->
  <li class="active"><a href="../home.php"><i>Practice Coding</i></a></li><br>
  <li class="active"><a href="../logout.php"><i>Logout</i></a></li><br>
</ul>

<div class="note">
  <h3>Created by Dhruvi Dobariya</h3>
  <p>ICT Department, Marwadi University</p>
</div>

</nav>

  <main>
  <script>
      $(document).ready(function(){
        $("#test").hide();
      });
      // $(document).ready(function(){
      //   $("#test1").hide();
      // });
    openfn = id => {
        $("#test").hide();
        $(id).show();
      };

      closefn = id => {
        $(id).hide();
        $("#test").show();
      };
    </script>
    
    <div class="content-columns" style="padding: 2rem;">
      <div style="width: 50%">
        <button onclick={openfn(test1)} style="height: 40px; width: 95%;">
        Pending Tasks</button>
        
        <div id="test1">
          <header>
            <div class="difficulty">
              <div class="h1" style="color: black; font-weight: bold; font-size: x-large;   margin-block-start: 0.67em; 
                                    margin-block-end: 0.67em;
                                    margin-inline-start: 0px;
                                    margin-inline-end: 0px;">
                <h1>TASK</h1>
              </div>
      <!-- <input type="radio" name="level" value="Easy"> Easy
      <input type="radio" name="level" value="Medium"> Medium
      <input type="radio" name="level"value="Hard"> Hard -->
              <form method="post" action="" style="width: 100%;">
              <table style="width: 100%;"><tr>
                <td style="width: 25%; border:0ch;"><input type='radio' name='level' value='Easy'>Easy</td>
                <td style="width: 25%; border:0ch;"><input type='radio' name='level' value='Medium'>Medium</td>
                <td style="width: 25%; border:0ch;"><input type='radio' name='level' value='Hard'>Hard</td>
                <td style="width: 25%; border:0ch;"><input type="submit" name="submit" value="Submit"> </td>
              </tr></table> 
                
                
                

                
                <!-- <a href="./level.php">click</a> -->
              </form>

              <?php
                if(isset($_POST['submit']))
                {
                   pending();
                } 
              ?>
            </div>
          </header>
          
          
          <script>
            function myFunction() {
              alert("Select");
            }
          </script>
        </div>
      </div>


      <div style="width: 50%">
      
        <button onclick={closefn(test1)} style="height: 40px; width: 95%;">
        Completed Tasks</button>
        
        <div id="test">
            <?php
              $count2 = "SELECT *
                        FROM completed
                        INNER JOIN problems
                        ON completed.taskid=problems.id WHERE completed.userid=".$_SESSION['user_id'];  
              $result2 = $conn->query($count2);
              echo "<div class='content-columns'>";
                echo "<div class='col'>";
                echo "<table class='tasks' style='z-index:1;width: auto;'>";
                echo "<tr><td><b>ID</b></td><td><b>Statement</b></td><td><b>Level</b></td><td><b>Points</b></td></tr>";
              if($result2->num_rows > 0)  
              {
                while($row = $result2->fetch_assoc())
                {
                  $ID = $row['id'];
                  // echo $ID;
                  // exit(0);
                  $statement = $row['statement'];
                  $difficulty = $row['difficulty'];
                  $points = $row['Points'];
                  // echo "<div class='content-columns'>";
                  //   echo "<div class='col'>";
                      echo "<form action='../home.php?taskid=$ID' method='post'>";
                        // echo "<table class='tasks' style='z-index:1;width: auto;'>";
                          echo "<tr>";
                            echo "<td>".$ID."</td>";
                            echo "<td>".$statement."</td>";
                            echo "<td>".$difficulty."</td>";
                            echo "<td>".$points."</td>";
                          echo "</tr>";
                        // echo "</table>";
                      echo "</form>";
                  //   echo "</div>";
                  // echo "</div>";
                  // $_SESSION['task'] = $ID;
                }
              }
              else
              {
                echo "Get Started with your first Program.";
              }
              echo "</table>";
              echo "</div>";
              echo "</div>";
            ?>
        </div>
      </div>

    </div>
    </div>

  </main>

</div>
<!-- partial -->
  <!-- <script  src="./script.js"></script> -->

</body>
</html>








<?php
  function pending()
  {
    $conn = mysqli_connect("localhost", "root", '', "iwtproject");  
    $level = $_POST['level'];
    // echo $level;
    // exit(0);
    // $count1 = "SELECT * FROM problems WHERE `difficulty` = '$level'";
    // $count1 = mysqli_query($conn,"SELECT COUNT(*) as id FROM `problems` WHERE `difficulty` = '$level'");
    // $row_count = $count1->fetch_assoc();
    
    $count1 = "SELECT DISTINCT prob.id,prob.statement,prob.difficulty,prob.Points FROM completed com, problems prob 
              WHERE prob.difficulty='$level' AND prob.id NOT IN(SELECT com.taskid FROM completed com 
              WHERE com.userid=".$_SESSION['user_id'].")";  
    $result = $conn->query($count1);
    // $result = mysql_query($count1,$conn);
    echo "<div class='content-columns'>";
    echo "<div class='col'>";
    echo "<table class='tasks' style='z-index:1;width: 100%;'>";
      echo "<tr><td><b>ID</b></td><td><b>Statement</b></td><td><b>Level</b></td><td><b>Points</b></td><td><b>Select</b></td></tr>";
    if($result->num_rows > 0)  
    {
      while($row = $result->fetch_assoc())
      {
        $ID = $row['id'];
        // echo $ID;
        // exit(0);
        $statement = $row['statement'];
        $difficulty = $row['difficulty'];
        $points = $row['Points'];
        // $password = $row['passward'];        
        // echo "<div class="item">".$ID.")".$statement.""."</div>";
       
            echo "<form action='../home.php?taskid=$ID' method='post'>";
              // echo "<table class='tasks' style='z-index:1;width: auto;'>";
                echo "<tr>";
                  echo "<td>".$ID."</td>";
                  echo "<td>".$statement."</td>";
                  echo "<td>".$difficulty."</td>";
                  echo "<td>".$points."</td>";
                  // echo "<td><button onclick='myFunction()'>Select</button></td>";
                  // echo "<td><button onclick='myFunction()'>Select</button></td>";
                  // echo "<td><button onclick='myFunction()'>Select</button></td>";
                  // echo "<td><button onclick='myFunction()'>Select</button></td>";
                  // echo "<td><button onclick='myFunction()'>Select</button></td>";
                  echo "<td><input type='submit' value='Select'></td>";
                echo "</tr>";
              // echo "</table>";
            echo "</form>";
        //   echo "</div>";
        // echo "</div>";
        // $_SESSION['task'] = $ID;
      }
    }
    else if($result->num_rows = 0)
    {
      echo "Congratulations! You have completed all $level level taks.";
    }
    echo "</table>";
    echo "</div>";
    echo "</div>";
  }
?>